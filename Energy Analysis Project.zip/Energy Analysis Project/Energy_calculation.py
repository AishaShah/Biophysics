
import math

import basic_setup
# Vander Waal energy


def distance(at1, at2):
    return at2-at1


def vdw_parameters(epsilon_i, sigma_i, epsilon_j, sigma_j):
    Ai = 2*math.sqrt(epsilon_i) * pow(sigma_i, 6)
    Aj = 2*math.sqrt(epsilon_j) * pow(sigma_j, 6)
    Ci = 2*math.sqrt(epsilon_i) * pow(sigma_i, 3)
    Cj = 2*math.sqrt(epsilon_j) * pow(sigma_j, 3)
    return Ai, Aj, Ci, Cj


def vdw_energy(epsilon_i, sigma_i, epsilon_j, sigma_j, rij):
    Ai, Aj, Ci, Cj = vdw_parameters(epsilon_i, sigma_i, epsilon_j, sigma_j)
    t1 = (Ai*Aj)/pow(rij, 12)
    t2 = (Ci*Cj)/pow(rij, 6)
    vdw_E = t1-t2
    return vdw_E

# Electrostatics
# def electrostatics(qi, qj, epsilon,r_ij):


def electrostatics(qi, qj, epsilon_i, epsilon_j, r_ij):
    # which r is used in this constant????
    Mehler_dielectric = ((86.9525)/(1 - 7.7839*math.exp(-0.3153*r_ij)))-8.85525
    E = 332.16*((qi*qj)/Mehler_dielectric*r_ij)

    return E


# SOlvation energy

def Solvation_energy(ASA, FSRF):
    delG_solv = 0
    for i in range(len(ASA)):
        delG_solv += ASA[i]*FSRF[i]
    return delG_solv


for res in resA:
    for atom in res.get_atoms():
        print(atom)


def solv_energy(st, residues_list):
    solv_energies = {}
    for res in residues_list:
        delG_solv = 0
        for atom in res.get_atoms():
            # calculate solvation of each atom
            # get value of sigma and ASA
            delG_solv += atom.xtra['vdw'].fsrf * atom.xtra['EXP_NACCESS']
        solv_energies[res] = delG_solv
    return solv_energies

    # return the total solvation energy of each residue


print(vars(st[0]['A'][42]['N']))

# srf=basic_setup.NACCESS_atomic
'''

CALCULATING TOTAL ENERGY:
sum=0
for each bond in in interface
    E=vdw+electrostatics+interface+solvation
    sum+=E
this will be total energy

Now change each residue in interface by Alanine one by one and calculate TOTAL ENERGY again 

'''
