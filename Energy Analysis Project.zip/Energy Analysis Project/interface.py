#!/usr/bin/env python
'''
1. Determine the list of residues in the interface of two chains

Parameters: PDB file name, distance
'''

import argparse
from Bio.PDB.PDBParser import PDBParser
from Bio.PDB.NeighborSearch import NeighborSearch
from Bio.PDB import PDBIO


def residue_id(res):  # residue as ASP A32
    # res.id[1] is integer, we should use str to get the corresponding string
    return res.get_resname() + ' ' + res.get_parent().id + str(res.id[1])


def atom_id(atom):  # atom as ASP A32.N, re-uses residue_id
    return residue_id(atom.get_parent()) + '.' + atom.id


parser = argparse.ArgumentParser(description='Interface residues')
parser.add_argument('pdb_file', help='file name ')
parser.add_argument('cutoff', type=float, help='cut-off distance')
args = parser.parse_args()


print('PDB:', args.pdb_file, 'Cut-off:', args.cutoff)


pdb_parser = PDBParser(PERMISSIVE=True)
st = pdb_parser.get_structure('', args.pdb_file)

# Generate 2 sets for the residues of both chains
resA = set()
resE = set()

# Generate a list for the atoms
select = []

# Add all atoms of the structure to the list
for at in st.get_atoms():
    select.append(at)

# Prepare Neighbor Search
nbsearch = NeighborSearch(select)


# By a neighbor search, check if the atoms are closer than 5 angstrom
dist = 0
for at1, at2 in sorted(nbsearch.search_all(args.cutoff)):
    if at1.get_parent().get_parent() != at2.get_parent().get_parent():
        # Add the residue ids of both atoms to their respective sets (no worries for repeated elements since it is a set)
        # resA.add(residue_id(at1.get_parent()))
        # resE.add(residue_id(at2.get_parent()))

        resA.add(at1.get_parent())
        resE.add(at2.get_parent())
        dist += 1
        print("Contact:", dist)
        print("Atom 1:", at1, at1.get_serial_number(),
              at1.get_parent().get_resname())
        print("Atom 2:", at2, at2.get_serial_number(),
              at2.get_parent().get_resname())

# Print the sets to check which residues are in the interface
# print(resA)
# print(resE)

# Print how many residues are contained in the sets
print('Chain A : ', len(resA))
print('Chain B : ', len(resE))

count_before = 0
for residue in st.get_residues():
    count_before += 1
print('BEFORE', count_before)


for residue in list(st.get_residues()):
    if residue not in resA:
        if residue not in resE:
            residue.get_parent().detach_child(residue.id)


count = 0
for residue in st.get_residues():
    count += 1
print(count)

io = PDBIO()
io.set_structure(st)
io.save("Interface.pdb")
