

import biobb_structure_checking
import biobb_structure_checking.constants as cts
from biobb_structure_checking.structure_checking import StructureChecking
base_dir_path = biobb_structure_checking.__path__[0]
args = cts.set_defaults(base_dir_path, {'notebook': True})

args['input_structure_path'] = '/home/aisha/BIOPHYSICS/6M0J.cif'
args['output_structure_path'] = '/home/aisha/BIOPHYSICS/6m0j_fixed.pdb'
args['output_structure_path_charges'] = '/home/aisha/BIOPHYSICS/6m0j_fixed.pdbqt'
args['debug'] = False
args['verbose'] = False


st_c = StructureChecking(base_dir_path, args)

##
