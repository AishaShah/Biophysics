#!/usr/bin/env python
'''
1. Determine the list of residues in interface of two chains

Parameters: PDB file name, distance, Chains (maybe optional? but we have to tell that interface between which chains)
'''
import numpy as np
import argparse
from Bio.PDB.PDBParser import PDBParser
from Bio.PDB.NeighborSearch import NeighborSearch


def residue_id(res):  # residue as ASP A32
    # res.id[1] is integer, we should use str to get the corresponding string
    return res.get_resname() + ' ' + res.get_parent().id + str(res.id[1])


def atom_id(atom):  # atom as ASP A32.N, re-uses residue_id
    return residue_id(atom.get_parent()) + '.' + atom.id


parser = argparse.ArgumentParser(
    description='Interface residues')
parser.add_argument('pdb_file', help='file name ')
parser.add_argument('cutoff', type=float, help='cut-off distance')
parser.add_argument('Chain1', help='First chain')
parser.add_argument('Chain2', help='second Chain')
args = parser.parse_args()


print('PDB:', args.pdb_file, 'Cut-off:', args.cutoff)


pdb_parser = PDBParser(PERMISSIVE=True)
st = pdb_parser.get_structure('', args.pdb_file)

for chain in st[0]:
    print(chain.id, len(chain))

#atoms_chainA = []
#atoms_chainB = []

residues_ChainA = set()
residues_ChainB = set()

MAXDIST = args.cutoff
C1 = args.Chain1
C2 = args.Chain2
Chain_A = st[0][C1]
Chain_B = st[0][C2]


# do we have to select atoms or residues??? but how can we finde distance between residues??
# ihavent checked if this script works
# also it is traversing throuh all atoms of two chains maybe somehow by neighbour search this will be more effecient??

npair = 0

for resA in Chain_A:
    for resB in Chain_B:
        for at1 in resA:
            for at2 in resB:
                dist = at2-at1

                if dist <= MAXDIST:

                    residues_ChainA.add(residue_id(resA))
                    residues_ChainB.add(residue_id(resB))

                    print("contact ", npair, ':',
                          atom_id(at1), atom_id(at2))
                    npair += 1
                    # atoms_chainA.append(at1)
                    # atoms_chainB.append(at2)
print(residues_ChainA)
print(residues_ChainB)

# we have to save selected atoms in new file??
